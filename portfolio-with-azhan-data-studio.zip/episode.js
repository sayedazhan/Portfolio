document.addEventListener('DOMContentLoaded', () => {
  const data = window.EPISODE_DATA;
  if (!data) return;

  let current = 1;
  let zoom = 1;
  const count = Number(data.count || 10);
  const main = document.getElementById('mainSlide');
  const counter = document.getElementById('slideCounter');
  const thumbs = Array.from(document.querySelectorAll('.thumb'));
  if (!main || !counter) return;

  const slideUrl = number => `${data.base}/${number}.png`;

  const viewer = document.createElement('div');
  viewer.className = 'slide-viewer';
  viewer.setAttribute('role', 'dialog');
  viewer.setAttribute('aria-modal', 'true');
  viewer.setAttribute('aria-hidden', 'true');
  viewer.innerHTML = `
    <div class="viewer-toolbar">
      <span class="viewer-counter" aria-live="polite"></span>
      <div class="viewer-toolbar-actions">
        <button class="viewer-tool" type="button" data-action="zoom-out" aria-label="Zoom out">−</button>
        <button class="viewer-tool viewer-zoom-value" type="button" data-action="reset" aria-label="Reset zoom">100%</button>
        <button class="viewer-tool" type="button" data-action="zoom-in" aria-label="Zoom in">+</button>
        <a class="viewer-tool viewer-original" target="_blank" rel="noopener" aria-label="Open full-size slide">↗</a>
        <button class="viewer-close" type="button" aria-label="Close viewer">×</button>
      </div>
    </div>
    <div class="viewer-stage">
      <div class="viewer-canvas"><img class="viewer-image" draggable="false" alt=""></div>
    </div>
    <button class="viewer-nav viewer-prev" type="button" aria-label="Previous slide">←</button>
    <button class="viewer-nav viewer-next" type="button" aria-label="Next slide">→</button>
    <div class="viewer-help">Pinch the screen or use + / − to zoom</div>
  `;
  document.body.appendChild(viewer);

  const stage = viewer.querySelector('.viewer-stage');
  const canvas = viewer.querySelector('.viewer-canvas');
  const image = viewer.querySelector('.viewer-image');
  const viewerCounter = viewer.querySelector('.viewer-counter');
  const zoomValue = viewer.querySelector('.viewer-zoom-value');
  const originalLink = viewer.querySelector('.viewer-original');

  function normalize(number) {
    return ((number - 1 + count) % count) + 1;
  }

  function setZoom(value) {
    zoom = Math.min(4, Math.max(1, value));
    canvas.style.width = `${zoom * 100}%`;
    zoomValue.textContent = `${Math.round(zoom * 100)}%`;
    stage.classList.toggle('is-zoomed', zoom > 1);
    if (zoom === 1) {
      stage.scrollLeft = 0;
      stage.scrollTop = 0;
    }
  }

  function updateViewer() {
    image.src = main.src;
    image.alt = main.alt;
    viewerCounter.textContent = `Slide ${current} of ${count}`;
    originalLink.href = main.src;
    setZoom(1);
  }

  function show(number) {
    current = normalize(number);
    main.src = slideUrl(current);
    main.alt = `Slide ${current} of ${data.title}`;
    counter.textContent = `Slide ${current} of ${count}`;
    thumbs.forEach((thumb, index) => thumb.classList.toggle('active', index === current - 1));
    if (viewer.classList.contains('open')) updateViewer();
  }

  function openViewer() {
    updateViewer();
    viewer.classList.add('open');
    viewer.setAttribute('aria-hidden', 'false');
    document.documentElement.classList.add('viewer-open');
    document.body.classList.add('viewer-open');
    viewer.querySelector('.viewer-close').focus({ preventScroll: true });
  }

  function closeViewer() {
    viewer.classList.remove('open');
    viewer.setAttribute('aria-hidden', 'true');
    document.documentElement.classList.remove('viewer-open');
    document.body.classList.remove('viewer-open');
    setZoom(1);
  }

  main.classList.add('zoomable-slide');
  main.tabIndex = 0;
  main.setAttribute('role', 'button');
  main.setAttribute('aria-label', 'Open slide in fullscreen viewer');

  const hint = document.createElement('button');
  hint.className = 'zoom-hint';
  hint.type = 'button';
  hint.textContent = 'Tap to zoom';
  main.closest('.slide-view')?.appendChild(hint);

  const fullscreenButton = document.createElement('button');
  fullscreenButton.className = 'open-fullscreen-btn';
  fullscreenButton.type = 'button';
  fullscreenButton.innerHTML = '<span aria-hidden="true">⛶</span> Open slide fullscreen';
  main.closest('.slide-view')?.insertAdjacentElement('afterend', fullscreenButton);

  document.getElementById('prevSlide')?.addEventListener('click', () => show(current - 1));
  document.getElementById('nextSlide')?.addEventListener('click', () => show(current + 1));
  thumbs.forEach((thumb, index) => thumb.addEventListener('click', () => show(index + 1)));
  main.addEventListener('click', openViewer);
  hint.addEventListener('click', openViewer);
  fullscreenButton.addEventListener('click', openViewer);
  main.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      openViewer();
    }
  });

  viewer.querySelector('.viewer-close').addEventListener('click', closeViewer);
  viewer.querySelector('.viewer-prev').addEventListener('click', () => show(current - 1));
  viewer.querySelector('.viewer-next').addEventListener('click', () => show(current + 1));
  viewer.querySelector('[data-action="zoom-in"]').addEventListener('click', () => setZoom(zoom + 0.5));
  viewer.querySelector('[data-action="zoom-out"]').addEventListener('click', () => setZoom(zoom - 0.5));
  zoomValue.addEventListener('click', () => setZoom(1));

  let lastTap = 0;
  stage.addEventListener('touchend', event => {
    if (event.changedTouches.length !== 1) return;
    const now = Date.now();
    if (now - lastTap < 320) {
      setZoom(zoom > 1 ? 1 : 2);
      lastTap = 0;
    } else {
      lastTap = now;
    }
  }, { passive: true });

  stage.addEventListener('wheel', event => {
    if (!event.ctrlKey) return;
    event.preventDefault();
    setZoom(zoom + (event.deltaY < 0 ? 0.25 : -0.25));
  }, { passive: false });

  viewer.addEventListener('click', event => {
    if (event.target === viewer) closeViewer();
  });

  document.addEventListener('keydown', event => {
    if (viewer.classList.contains('open')) {
      if (event.key === 'Escape') closeViewer();
      if (event.key === 'ArrowLeft') show(current - 1);
      if (event.key === 'ArrowRight') show(current + 1);
      if (event.key === '+' || event.key === '=') setZoom(zoom + 0.5);
      if (event.key === '-') setZoom(zoom - 0.5);
    }
  });

  show(1);
});
