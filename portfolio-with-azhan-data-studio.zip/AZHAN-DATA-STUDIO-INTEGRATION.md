# Azhan Data Studio — Portfolio Integration

This update adds Azhan Data Studio as the flagship live data product on the portfolio.

## Added
- Flagship product callout in the homepage hero
- Large first Featured Project card for Azhan Data Studio
- Live App CTA: https://azhandatastudio.netlify.app/
- Dedicated case study: `azhan-data-studio.html`
- New product preview asset: `assets/azhan-data-studio-preview.svg`

## Updated
- Featured Projects description now covers data products, analytics, automation and research
- Future Mobility Lab remains featured, now after Azhan Data Studio
- Portfolio metadata broadened beyond dashboard-only positioning

## Deploy
Upload/deploy the complete portfolio folder to the same Netlify site currently serving your portfolio.
No new npm packages, build tools or backend services are required for this portfolio update.
