@echo off
setlocal
cd /d "%~dp0"
echo.
echo Ask Azhan AI V2 - Netlify production deployment
echo Current folder: %CD%
echo.
netlify status >nul 2>&1
if errorlevel 1 (
  echo This folder must be linked to your existing Netlify project first.
  echo Select your existing syedazhan portfolio when prompted.
  echo.
  netlify link
  if errorlevel 1 goto failed
)
echo.
echo Deploying website and Node.js Function...
netlify deploy --prod --dir . --functions netlify/functions
if errorlevel 1 goto failed
echo.
echo Deployment complete.
echo Test: https://syedazhan.netlify.app/.netlify/functions/ask-azhan
echo.
pause
exit /b 0
:failed
echo.
echo Deployment did not complete. Read the message above.
pause
exit /b 1
