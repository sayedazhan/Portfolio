const knowledge = require('../../assets/azhan-knowledge.json');

const STOP_WORDS = new Set(
  'a an and are as at be by can do for from has have how i in is it me my of on or our should that the this to what when where which who why with you your'.split(' ')
);

const model = process.env.GEMINI_MODEL || "gemini-3.6-flash";

function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    },
    body: JSON.stringify(body),
  };
}

function clean(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9&+.# -]/g, ' ');
}

function terms(value) {
  return [...new Set(
    clean(value)
      .split(/\s+/)
      .filter((word) => word.length > 1 && !STOP_WORDS.has(word))
  )];
}

function retrieve(question) {
  const queryTerms = terms(question);
  const normalizedQuestion = clean(question);

  return knowledge.entries
    .map((entry) => {
      const title = clean(entry.title);
      const series = clean(entry.series);
      const body = clean([
        entry.summary,
        ...(entry.topics || []),
        entry.searchText,
      ].join(' '));

      let score = 0;
      for (const term of queryTerms) {
        if (title.includes(term)) score += 8;
        if (series.includes(term)) score += 5;
        if (body.includes(term)) score += 2;
      }

      if (/who is azhan|about azhan|experience|skills|portfolio/.test(normalizedQuestion) && entry.type === 'profile') score += 20;
      if (/agent/.test(normalizedQuestion) && entry.series === 'AI Agent Builder') score += 3;
      if (/work|copilot|productivity|meeting|email/.test(normalizedQuestion) && entry.series === 'AI at Work') score += 3;
      if (/data|power bi|sql|fabric|analyst/.test(normalizedQuestion) && entry.series === 'AI & Data Mastery') score += 3;

      return { entry, score };
    })
    .filter(({ score }) => score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 6)
    .map(({ entry }) => entry);
}

function extractText(data) {
  return data?.candidates?.[0]?.content?.parts
    ?.map((part) => part.text || '')
    .join('')
    .trim();
}

exports.handler = async function handler(event) {
  if (event.httpMethod === 'OPTIONS') return json(204, {});

  // A simple browser test: opening the function URL confirms deployment and key visibility.
  if (event.httpMethod === 'GET') {
    return json(200, {
      ok: true,
      service: 'Ask Azhan AI',
      functionRuntime: 'Node.js Netlify Function',
      apiKeyConfigured: Boolean(process.env.GEMINI_API_KEY),
      model: MODEL,
    });
  }

  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed.' });

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return json(503, {
      error: 'The Gemini key is not available to this deployment. Add GEMINI_API_KEY in Netlify, then deploy this complete project again.',
      code: 'MISSING_GEMINI_KEY',
    });
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return json(400, { error: 'Invalid request body.' });
  }

  const question = String(payload.question || '').trim();
  if (!question || question.length > 600) {
    return json(400, { error: 'Please enter a question of up to 600 characters.' });
  }

  const matches = retrieve(question);
  const context = matches.length
    ? matches.map((entry, index) => [
        `SOURCE ${index + 1}`,
        `Title: ${entry.title}`,
        `Series: ${entry.series || 'Portfolio'}`,
        entry.episode ? `Episode: ${entry.episode}` : '',
        `Summary: ${entry.summary}`,
        `Topics: ${(entry.topics || []).join(', ')}`,
        `URL: ${entry.url}`,
      ].filter(Boolean).join('\n')).join('\n\n')
    : 'No closely matching portfolio source was found.';

  const history = Array.isArray(payload.history)
    ? payload.history.slice(-6).map((item) =>
        `${item.role}: ${String(item.text || '').slice(0, 800)}`
      ).join('\n')
    : 'None';

  const prompt = `You are Ask Azhan AI, the helpful guide for Syed Azhan Hassan's professional portfolio.
Answer only from the supplied portfolio context. Be concise, practical, and friendly.
Never invent credentials, jobs, projects, episode details, or expertise.
If the context does not support an answer, clearly say the portfolio does not cover it yet.
When relevant, mention the exact series and episode. Do not print raw URLs because the interface adds source buttons.

PORTFOLIO CONTEXT
${context}

RECENT CONVERSATION
${history || 'None'}

VISITOR QUESTION
${question}`;

  try {
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`;
    const geminiResponse = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: {
          maxOutputTokens: 500,
        },
      }),
    });

    const data = await geminiResponse.json().catch(() => ({}));

    if (!geminiResponse.ok) {
      console.error('Gemini API error', geminiResponse.status, JSON.stringify(data));
      const upstreamMessage = data?.error?.message || '';
      let publicMessage = 'Gemini could not answer right now. Please try again shortly.';
      if (geminiResponse.status === 400) publicMessage = 'The selected Gemini model or request is not available. Check GEMINI_MODEL in Netlify.';
      if (geminiResponse.status === 401 || geminiResponse.status === 403) publicMessage = 'Gemini rejected the API key. Create a valid key in Google AI Studio and update GEMINI_API_KEY in Netlify.';
      if (geminiResponse.status === 429) publicMessage = 'The free Gemini quota has been reached. Please try again later.';
      return json(502, {
        error: publicMessage,
        code: 'GEMINI_API_ERROR',
        details: upstreamMessage.slice(0, 240),
      });
    }

    const answer = extractText(data);
    if (!answer) return json(502, { error: 'Gemini returned an empty response.' });

    const sources = matches.slice(0, 4).map((entry) => ({
      label: entry.type === 'episode'
        ? `${entry.series} · Episode ${entry.episode}`
        : 'About Azhan',
      url: entry.url,
    }));

    return json(200, { answer, sources });
  } catch (error) {
    console.error('Ask Azhan function error', error);
    return json(500, {
      error: 'The server function could not reach Gemini. Please try again shortly.',
      code: 'FUNCTION_ERROR',
    });
  }
};
