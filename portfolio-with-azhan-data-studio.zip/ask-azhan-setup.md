# Ask Azhan AI setup

1. Create a Gemini API key in Google AI Studio.
2. In Netlify, open Site configuration > Environment variables.
3. Add `GEMINI_API_KEY` and paste the key as its value.
4. Optional: add `GEMINI_MODEL` to override the default `gemini-2.5-flash`.
5. Deploy the entire project folder or connect the repository to Netlify.
6. Test the floating **Ask Azhan AI** button on the deployed site. Netlify Functions do not run by opening HTML files directly on your computer.

Security: never add the actual API key to these project files or commit it to GitHub.
