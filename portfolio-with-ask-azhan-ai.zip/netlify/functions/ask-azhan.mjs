import knowledge from "../../assets/azhan-knowledge.json" with { type: "json" };

const STOP = new Set("a an and are as at be by can do for from has have how i in is it me my of on or our should that the this to what when where which who why with you your".split(" "));
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const clean = s => String(s || "").toLowerCase().replace(/[^a-z0-9&+.# -]/g, " ");
const terms = s => [...new Set(clean(s).split(/\s+/).filter(w => w.length > 1 && !STOP.has(w)))];
function retrieve(question) {
  const q = terms(question);
  return knowledge.entries.map(e => {
    const title = clean(e.title), series = clean(e.series), body = clean([e.summary, ...(e.topics || []), e.searchText].join(" "));
    let score = 0;
    for (const t of q) { if (title.includes(t)) score += 8; if (series.includes(t)) score += 5; if (body.includes(t)) score += 2; }
    if (/who is azhan|about azhan|experience|skills|portfolio/.test(clean(question)) && e.type === "profile") score += 20;
    if (/agent/.test(clean(question)) && e.series === "AI Agent Builder") score += 3;
    if (/work|copilot|productivity|meeting|email/.test(clean(question)) && e.series === "AI at Work") score += 3;
    if (/data|power bi|sql|fabric|analyst/.test(clean(question)) && e.series === "AI & Data Mastery") score += 3;
    return {e, score};
  }).filter(x => x.score > 0).sort((a,b)=>b.score-a.score).slice(0,6).map(x=>x.e);
}
const response = (status, body) => new Response(JSON.stringify(body), {status, headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store"}});
export default async (req) => {
  if (req.method !== "POST") return response(405,{error:"Method not allowed"});
  if (!process.env.GEMINI_API_KEY) return response(503,{error:"Ask Azhan AI is not configured yet. Add GEMINI_API_KEY in Netlify and redeploy."});
  let payload; try { payload=await req.json(); } catch { return response(400,{error:"Invalid request"}); }
  const question=String(payload.question||"").trim();
  if (!question || question.length>600) return response(400,{error:"Please enter a question of up to 600 characters."});
  const matches=retrieve(question);
  const context=matches.length ? matches.map((e,i)=>`SOURCE ${i+1}\nTitle: ${e.title}\nSeries: ${e.series||'Portfolio'}${e.episode?`\nEpisode: ${e.episode}`:''}\nSummary: ${e.summary}\nTopics: ${(e.topics||[]).join(', ')}\nURL: ${e.url}`).join("\n\n") : "No closely matching portfolio source was found.";
  const history=Array.isArray(payload.history)?payload.history.slice(-6).map(x=>`${x.role}: ${String(x.text||'').slice(0,800)}`).join('\n'):'';
  const prompt=`You are Ask Azhan AI, the helpful guide for Syed Azhan Hassan's professional portfolio.\nAnswer using ONLY the supplied portfolio context. Be concise, practical and friendly. Never claim Azhan has credentials, jobs, projects or expertise not present in the context. If the context does not support the answer, say that the portfolio does not cover it yet. When relevant, name the series and episode. Do not output raw URLs because the interface adds source buttons.\n\nPORTFOLIO CONTEXT\n${context}\n\nRECENT CONVERSATION\n${history || 'None'}\n\nVISITOR QUESTION\n${question}`;
  try {
    const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(process.env.GEMINI_API_KEY)}`;
    const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{temperature:0.25,maxOutputTokens:500}})});
    const data=await r.json();
    if(!r.ok) { console.error('Gemini error',r.status,data); return response(502,{error:"The AI service could not answer right now. Check the Gemini key, model and quota."}); }
    const answer=data?.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('').trim();
    if(!answer) return response(502,{error:"The AI service returned an empty response."});
    const sources=matches.slice(0,4).map(e=>({label:e.type==='episode'?`${e.series} · Episode ${e.episode}`:'About Azhan',url:e.url}));
    return response(200,{answer,sources});
  } catch (err) { console.error(err); return response(500,{error:"The assistant encountered a server error."}); }
};
